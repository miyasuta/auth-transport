sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageBox"], function (__BaseController, JSONModel, MessageBox) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);

  /**
   * @namespace miyasuta.transportui.controller
   */
  const Destinations = BaseController.extend("miyasuta.transportui.controller.Destinations", {
    onInit: function _onInit() {
      this.getRouter().getRoute("destinations").attachPatternMatched(this._onRouteMatched, this);
      this._messageManager = sap.ui.getCore().getMessageManager(); //this.getView().setModel(this._messageManager.getMessageModel(), "message");

      this._messageManager.registerObject(this.getView(), true);
    },
    onAddDestination: async function _onAddDestination() {
      let dialog = await this.loadFragment("DestinationConfig");
      this._dialog = dialog;

      this._dialog.open();
    },
    onInputChange: function _onInputChange(oEvent) {
      let input = oEvent.getSource();

      this._validateInput(input);
    },
    onDeleteDestination: function _onDeleteDestination(oEvent) {
      let context = oEvent.getParameter("listItem").getBindingContext();
      MessageBox.confirm(this.getResourceBundle().getText("confirmDelete"), {
        onClose: oAction => {
          if (oAction === sap.m.MessageBox.Action.OK) {
            context.delete();
          }
        }
      });
    },
    onCreateDestination: function _onCreateDestination() {
      //pre check
      if (!this._validated()) {
        return;
      }

      ; //remove messages

      this._messageManager.removeAllMessages(); //post destination


      let viewModel = this.getView().getModel("viewModel");
      let data = {
        destination: viewModel.getProperty("/destinationName"),
        suffix: viewModel.getProperty("/suffix")
      }; //let listBinding = this.byId("destinationConfig").getBinding("items") as ODataListBinding;

      let listBinding = this._getListBinding();

      listBinding.attachCreateCompleted(this._onCreateCompleted, this);
      listBinding.create(data);
      this.getView().getModel().submitBatch(Destinations.groupId).then(() => {
        this._dialog.close();
      }).catch(error => {
        this._dialog.close();

        MessageBox.error(error.message);
      });
    },
    onCancel: function _onCancel() {
      this._dialog.close();
    },
    _validateInput: function _validateInput(input) {
      let valusState = "None";
      let validationError = false;
      let binding = input.getBinding("value");

      try {
        binding.getType().validateValue(input.getValue());
      } catch (exception) {
        validationError = true;
        valusState = "Error";
      }

      input.setValueState(valusState);
      input.setValueStateText(this.getResourceBundle().getText("inputRequired"));
      return validationError;
    },
    _validated: function _validated() {
      let inputs = [this.byId("inputDestination"), this.byId("inputSuffix")];
      let validated = true;
      inputs.forEach(input => {
        validated = !this._validateInput(input) && validated;
      }, this);
      return validated; // let validated = true;
      // this._clearValueState("inputDestination");
      // this._clearValueState("inputSuffix");
      // let viewModel = this.getView().getModel("viewModel") as JSONModel;
      // let destinationName = viewModel.getProperty("/destinationName");
      // let suffix = viewModel.getProperty("/suffix");
      // if (!destinationName) {
      // 	this._setValueStateError("inputDestination");
      // 	validated = false;
      // }
      // if(!suffix) {
      // 	this._setValueStateError("inputSuffix");
      // 	validated = false;
      // }
      // return validated;
    },
    _clearValueState: function _clearValueState(id) {
      let dest = this.byId(id);
      dest.setValueState("None");
    },
    _setValueStateError: function _setValueStateError(id) {
      let dest = this.byId(id);
      dest.setValueState("Error");
      dest.setValueStateText(this.getResourceBundle().getText("inputRequired"));
    },
    _getListBinding: function _getListBinding() {
      if (!this._listBinding) {
        this._listBinding = this.getView().getModel().bindList("/Suffix", null, null, null, {
          $$updateGroupId: Destinations.groupId
        }); //this._listBinding = this.byId("destinationConfig").getBinding("items") as ODataListBinding;
      }

      return this._listBinding;
    },
    _destroyListBinding: function _destroyListBinding() {
      this._listBinding.destroy();

      this._listBinding = undefined;
    },
    _onRouteMatched: function _onRouteMatched() {
      this._initializeModel();
    },
    _onCreateCompleted: function _onCreateCompleted() {
      this._initializeModel(); //show message


      let messageModel = this._messageManager.getMessageModel();

      let message = messageModel.getData()[0];

      if (message) {
        MessageBox.error(message.message);
      } //reset pednding changes
      //error "Cannot cancel the changes for group 'createDest', the batch request is running" is issued,
      //but changes are reset anyway.


      let oDataModel = this.getView().getModel();

      if (oDataModel.hasPendingChanges()) {
        oDataModel.resetChanges(Destinations.groupId);
      } //initialize binding


      this._getListBinding().detachCreateCompleted(this._onCreateCompleted, this);

      let items = this.byId("destinationConfig").getBinding("items");
      items.refresh();
    },
    _initializeModel: function _initializeModel() {
      let viewModel = new JSONModel({
        destinationName: "",
        suffix: ""
      });
      this.getView().setModel(viewModel, "viewModel");
    }
  });
  Destinations.groupId = "createDest";
  return Destinations;
});
//# sourceMappingURL=Destinations.controller.js.map