sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageStrip"], function (__BaseController, JSONModel, MessageStrip) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);

  /**
   * @namespace miyasuta.transportui.controller
   */
  const RoleCollections = BaseController.extend("miyasuta.transportui.controller.RoleCollections", {
    onInit: function _onInit() {
      this.getRouter().getRoute("rolecollections").attachPatternMatched(this._onRouteMatched, this); //store messages for destination validation

      this._setMessageStrips();
    },
    onValidateDestinations: function _onValidateDestinations() {
      //remove all message strips
      this._messageStrips.forEach(messageStrip => {
        this.byId("selectDestinations").removeContent(messageStrip);
      }); //check destinations are not empty and not the same


      let viewModel = this.getView().getModel("viewModel");
      let source = viewModel.getProperty("/destinations/source");
      let target = viewModel.getProperty("/destinations/target");

      if (source === "" || target === "") {
        this.byId("selectDestinations").insertContent(this._messageStrips[0], 0);
        this.byId("step1").setValidated(false);
        return;
      }

      if (source === target) {
        this.byId("selectDestinations").insertContent(this._messageStrips[1], 0);
        this.byId("step1").setValidated(false);
        return;
      }

      this.byId("step1").setValidated(true);
    },
    onRoleCollectionsInput: function _onRoleCollectionsInput(oEvent) {
      let text = this.getView().getModel("viewModel").getProperty("/roleCollectionsInput");
      let roleCollections = text.split("\n"); //remove blank lines

      roleCollections = roleCollections.reduce((arr, current) => {
        if (current !== "") {
          arr.push({
            name: current,
            status: this.getResourceBundle().getText("progress")
          });
        }

        return arr;
      }, []);
      this.getView().getModel("viewModel").setProperty("/roleCollections", roleCollections);
    },
    onComplete: async function _onComplete(oEvent) {
      //swith to transport view
      let fragment = await this.loadFragment("Transport");

      this._setNewContent(fragment);

      this.byId("transportLayout").removeContent(this._messageStrips[3]);
      this.byId("transportLayout").insertContent(this._messageStrips[2], 0);

      this._doTrnsport().then(results => {
        this._mapResults(results);

        this._switchMessageStrips();
      });
    },
    formatStatus: function _formatStatus(status) {
      switch (status) {
        case "Progress":
          return "None";

        case "Success":
          return "Success";

        case "Error":
          return "Error";

        default:
          return "None";
      }
    },
    _setMessageStrips: function _setMessageStrips() {
      this._messageStrips = [];

      this._AddMessageStrip("roleCollections.destinations.empty", "Information");

      this._AddMessageStrip("roleCollections.destinations.same", "Error");

      this._AddMessageStrip("transportMessage", "Warning");

      this._AddMessageStrip("transportComplete", "Success");
    },
    _AddMessageStrip: function _AddMessageStrip(text, type) {
      let messageStrip = new MessageStrip({
        text: this.getResourceBundle().getText(text),
        type: type,
        showIcon: true
      });

      this._messageStrips.push(messageStrip);
    },
    _onRouteMatched: async function _onRouteMatched(oEvent) {
      this._initializeModel();

      let wizard = await this.loadFragment("Wizard"); //initialize wizard

      wizard.discardProgress(wizard.getSteps()[0], true);
      this.byId("step1").setValidated(false);
      this.byId("selectDestinations").insertContent(this._messageStrips[0], 0);

      this._setNewContent(wizard); //refresh binding of destinations


      this.byId("source").getBinding("items").refresh();
      this.byId("target").getBinding("items").refresh();
    },
    _setNewContent: function _setNewContent(newContent) {
      let page = this.byId("roleCollectionPage");
      page.removeAllContent();
      page.addContent(newContent); // let dynamicPage = this.byId("roleCollectionPage") as DynamicPage;
      // dynamicPage.setContent(newContent);
    },
    _initializeModel: function _initializeModel() {
      var oModel = new JSONModel({
        destinations: {
          source: "",
          target: ""
        },
        roleCollectionsInput: "",
        roleCollections: []
      });
      this.getView().setModel(oModel, "viewModel");
    },
    _doTrnsport: async function _doTrnsport() {
      let viewModel = this.getView().getModel("viewModel");
      let roleCollections = viewModel.getProperty("/roleCollections").map(roleCollection => roleCollection.name);
      let source = viewModel.getProperty("/destinations/source");
      let target = viewModel.getProperty("/destinations/target");
      let data = {
        destinations: {
          source: source,
          target: target
        },
        roleCollections: roleCollections
      };
      let settings = {
        url: "/auth-transport/transportRoleCollections",
        method: "POST",
        async: true,
        headers: {
          "Content-Type": "application/json"
        },
        data: JSON.stringify(data)
      };
      return new Promise((resolve, reject) => {
        $.ajax(settings).done(response => {
          resolve(response.value);
        }).fail(error => {
          reject(error);
        });
      });
    },
    _mapResults: function _mapResults(results) {
      let viewModel = this.getView().getModel("viewModel");
      let roleCollections = viewModel.getProperty("/roleCollections");
      results.forEach(result => {
        let roleCollection = roleCollections.find(roleCollection => roleCollection.name === result.roleCollection);
        roleCollection.status = this.getResourceBundle().getText(result.result);
        roleCollection.message = result.message;
      });
      viewModel.setProperty("/roleCollections", roleCollections);
    },
    _switchMessageStrips: function _switchMessageStrips() {
      this.byId("transportLayout").removeContent(this._messageStrips[2]);
      this.byId("transportLayout").insertContent(this._messageStrips[3], 0);
    }
  });
  return RoleCollections;
});
//# sourceMappingURL=RoleCollections.controller.js.map