sap.ui.define(["./BaseController"], function (__BaseController) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace miyasuta.transportui.controller
   */


  const Transport = BaseController.extend("miyasuta.transportui.controller.Transport", {});
  return Transport;
});
//# sourceMappingURL=Transport.controller.js.map