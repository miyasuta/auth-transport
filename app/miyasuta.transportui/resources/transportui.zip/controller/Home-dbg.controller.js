sap.ui.define(["./BaseController"], function (__BaseController) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace miyasuta.transportui.controller
   */


  const Home = BaseController.extend("miyasuta.transportui.controller.Home", {
    sayHello: function _sayHello() {}
  });
  return Home;
});
//# sourceMappingURL=Home.controller.js.map