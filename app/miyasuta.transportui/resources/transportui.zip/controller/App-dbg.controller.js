sap.ui.define(["./BaseController"], function (__BaseController) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);

  /**
   * @namespace miyasuta.transportui.controller
   */
  const App = BaseController.extend("miyasuta.transportui.controller.App", {
    onInit: function _onInit() {
      // apply content density mode to root view
      this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
    },
    onSideNavButtonPress: function _onSideNavButtonPress() {
      var oToolPage = this.byId("toolPage");
      oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
    },
    onItemSelect: function _onItemSelect(oEvent) {
      var oItem = oEvent.getParameter("item");
      var sKey = oItem.getKey();
      var oRouter = this.getRouter();
      oRouter.navTo(sKey);
    }
  });
  return App;
});
//# sourceMappingURL=App.controller.js.map