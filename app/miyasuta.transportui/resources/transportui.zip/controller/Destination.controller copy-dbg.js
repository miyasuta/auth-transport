sap.ui.define(["./BaseController"], function (__BaseController) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);

  /**
   * @namespace miyasuta.transportui.controller
   */
  const Main = BaseController.extend("miyasuta.transportui.controller.Main", {
    onSideNavButtonPress: function _onSideNavButtonPress() {
      var oToolPage = this.byId("toolPage");
      oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
    }
  });
  return Main;
});
//# sourceMappingURL=Destination.controller copy.js.map