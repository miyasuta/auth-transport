sap.ui.define(["./BaseController"], function (__BaseController) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);

  /**
   * @namespace miyasuta.transportui.controller
   */
  const Destination = BaseController.extend("miyasuta.transportui.controller.Destination", {
    onSideNavButtonPress: function _onSideNavButtonPress() {
      var oToolPage = this.byId("toolPage");
      oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
    }
  });
  return Destination;
});
//# sourceMappingURL=Destination.controller.js.map