sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageStrip"], function (__BaseController, JSONModel, MessageStrip) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);

  /**
   * @namespace miyasuta.transportui.controller
   */
  const RoleCollections = BaseController.extend("miyasuta.transportui.controller.RoleCollections", {
    onInit: function _onInit() {
      var oModel = new JSONModel({
        destinations: {
          source: "",
          target: ""
        },
        roleCollections: []
      });
      this.getView().setModel(oModel, "viewModel"); //store messages for destination validation

      this._setMessageStrips();
    },
    onValidateDestinations: function _onValidateDestinations() {
      //remove all message strips
      this._messageStrips.forEach(messageStrip => {
        this.byId("selectDestinations").removeContent(messageStrip);
      }); //check destinations are not empty and not the same


      let viewModel = this.getView().getModel("viewModel");
      let source = viewModel.getProperty("/destinations/source");
      let target = viewModel.getProperty("/destinations/target");

      if (source === "" || target === "") {
        this.byId("selectDestinations").insertContent(this._messageStrips[0], 0);
        this.byId("step1").setValidated(false);
        return;
      }

      if (source === target) {
        this.byId("selectDestinations").insertContent(this._messageStrips[1], 0);
        this.byId("step1").setValidated(false);
        return;
      }

      this.byId("step1").setValidated(true);
    },
    onRoleCollectionsInput: function _onRoleCollectionsInput(oEvent) {
      let text = oEvent.getSource().getValue();
      let roleCollections = text.split("\n"); //remove blank lines

      roleCollections = roleCollections.reduce((arr, current) => {
        if (current !== "") {
          arr.push({
            name: current
          });
        }

        return arr;
      }, []);
      this.getView().getModel("viewModel").setProperty("/roleCollections", roleCollections);
    },
    _setMessageStrips: function _setMessageStrips() {
      this._messageStrips = [];
      let messageStrip1 = new MessageStrip({
        text: this.getResourceBundle().getText("roleCollections.destinations.empty"),
        type: "Information",
        showIcon: true
      });

      this._messageStrips.push(messageStrip1);

      let messageStrip2 = new MessageStrip({
        text: this.getResourceBundle().getText("roleCollections.destinations.same"),
        type: "Error",
        showIcon: false
      });

      this._messageStrips.push(messageStrip2);
    }
  });
  return RoleCollections;
});
//# sourceMappingURL=RoleCollections.controller copy.js.map